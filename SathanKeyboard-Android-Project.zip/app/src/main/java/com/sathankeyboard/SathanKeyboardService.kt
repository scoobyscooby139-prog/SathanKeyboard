package com.sathankeyboard

import android.inputmethodservice.InputMethodService
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.graphics.Color
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class SathanKeyboardService : InputMethodService() {

    private var sinhala = true

    private val sinhalaRows = listOf(
        listOf("අ","ආ","ඇ","ඈ","ඉ","ඊ","උ","ඌ","එ","ඒ","ඔ","ඕ"),
        listOf("ක","ඛ","ග","ඝ","ච","ඡ","ජ","ඣ","ට","ඨ","ඩ","ණ"),
        listOf("ත","ථ","ද","ධ","න","ප","ඵ","බ","භ","ම","ය","ර"),
        listOf("ල","ව","ශ","ෂ","ස","හ","ළ","ෆ","ං","ඃ","්","ා")
    )

    private val englishRows = listOf(
        listOf("Q","W","E","R","T","Y","U","I","O","P"),
        listOf("A","S","D","F","G","H","J","K","L"),
        listOf("Z","X","C","V","B","N","M")
    )

    override fun onCreateInputView(): View {
        return buildKeyboard()
    }

    private fun buildKeyboard(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(4, 4, 4, 4)
            setBackgroundColor(Color.rgb(235, 235, 235))
        }

        val title = TextView(this).apply {
            text = if (sinhala) "සිංහල" else "English"
            textSize = 14f
            setTextColor(Color.DKGRAY)
            setPadding(8, 4, 8, 4)
        }
        root.addView(title, LinearLayout.LayoutParams(-1, 36))

        val rows = if (sinhala) sinhalaRows else englishRows
        rows.forEach { row ->
            val line = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
            }
            row.forEach { key ->
                line.addView(makeKey(key, 1f))
            }
            root.addView(line, LinearLayout.LayoutParams(-1, 52))
        }

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        bottom.addView(makeKey(if (sinhala) "EN" else "සිං", 1.2f) {
            sinhala = !sinhala
            setInputView(buildKeyboard())
        })
        bottom.addView(makeKey("Space", 3f) {
            currentInputConnection?.commitText(" ", 1)
        })
        bottom.addView(makeKey("⌫", 1.2f) {
            deleteOne()
        })
        bottom.addView(makeKey("↵", 1.2f) {
            sendEnter()
        })
        root.addView(bottom, LinearLayout.LayoutParams(-1, 52))

        return root
    }

    private fun makeKey(text: String, weight: Float, action: (() -> Unit)? = null): Button {
        return Button(this).apply {
            this.text = text
            textSize = if (text.length > 2) 12f else 16f
            setAllCaps(false)
            setPadding(0, 0, 0, 0)
            setOnClickListener {
                if (action != null) action()
                else currentInputConnection?.commitText(text, 1)
            }
            layoutParams = LinearLayout.LayoutParams(0, -1, weight).apply {
                setMargins(2, 2, 2, 2)
            }
        }
    }

    private fun deleteOne() {
        val ic = currentInputConnection ?: return
        ic.deleteSurroundingText(1, 0)
    }

    private fun sendEnter() {
        val ic: InputConnection = currentInputConnection ?: return
        val action = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION)
            ?: EditorInfo.IME_ACTION_NONE
        if (action != EditorInfo.IME_ACTION_NONE) {
            ic.performEditorAction(action)
        } else {
            ic.commitText("\n", 1)
        }
    }
}
