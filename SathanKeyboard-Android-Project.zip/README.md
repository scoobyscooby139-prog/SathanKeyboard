# SathanKeyboard

Sinhala & English Android Keyboard.

## Features
- Sinhala keyboard
- English keyboard
- Sinhala / English switch button
- Space, backspace and enter
- Works as an Android Input Method Service

## Build
Open this project in Android Studio and build the APK.

## Install / Enable
After installing the APK:
1. Open Sathan Keyboard.
2. Open Keyboard Settings.
3. Enable Sathan Keyboard.
4. Choose Sathan Keyboard as the current keyboard.
